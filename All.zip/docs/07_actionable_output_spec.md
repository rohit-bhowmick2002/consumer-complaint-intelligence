# 7. Actionable Output - Specification

## Principle: Do not end with "here are the trends." End with which items require investigation, estimated exposure, responsible owner, due date, status, recommended action.

### Output Files

1. **reports/actionable_exceptions.csv** - 7,725 rows (each exception)
2. **reports/exception_summary_by_owner.csv** - aggregated by owner and priority
3. This spec document

### Schema for actionable_exceptions.csv

| Column | Definition | Example |
|--------|------------|---------|
| complaint_id | CFPB complaint ID, PK | 7000015 |
| date_received | Date complaint received | 2023-06-21 |
| date_sent_to_company | Date sent to company | 2023-07-14 |
| company | Financial institution | JPMORGAN CHASE & CO. |
| product | Product | Credit reporting... |
| issue | Consumer issue | Improper use of your report |
| state | Consumer state | OK |
| zip_code | Zip | 29410 |
| exception_type | Classification | Timely Breach, Unmapped Entity, Unexpected Product, Late Arriving |
| days_to_company | Calculation | 23 |
| estimated_exposure_$ | Cost × assumption | 450 |
| control_id | Mapped control | CTRL-TIME-002 |
| responsible_owner | Person/team | Compliance Ops, Compliance Ops Lead, Master Data Mgmt, Product Risk Manager |
| due_date | Based on priority | 2026-07-12 (P1 = 2 days, P2=5 days, P3=10 days) from today 2026-07-10 |
| status | Open / In Progress | Open |
| priority | P1 Critical, P2 High, P3 Medium | P2 |
| recommended_action | Specific action | Investigate why complaint >15 days - check SLA breach for Critical tier company - RCA staffing/system |
| drillthrough_path | Drill-through lineage | Executive KPI (Exception Rate) -> Company:JPMORGAN CHASE & CO. -> Product:Credit reporting -> Complaint ID:7000015 -> Control Owner:Compliance Ops |

### Priority Logic

- **P1:** Company risk tier = Critical (EQUIFAX, Experian, TRANSUNION) AND timely breach >15 days. SLA 48h. Escalate to CCO.
- **P2:** High tier (BOA, CHASE, WELLS) OR unmapped entity OR timely breach for Medium tier. SLA 5 days.
- **P3:** Unexpected product OR missing zip OR invalid state. SLA 10-14 days.

### Estimated Exposure Methodology (Analyst Assumption + Risk Indicator)

- Assumption: $450 per investigation (What-If $100-$5000)
- Unmapped entity cost $270 (less investigation, more master onboarding)
- Unexpected product $100 (taxonomy review)
- Formula: `Exposure = Count × CostPerCase`
- Total exposure for current batch: calculated in summary
- Rolling 12M: same calculation for trend

**From latest run:**
- Timely Breach (P2): 7,167 × $450 = $3,225,150
- Timely Breach (P1 Critical): 218 × $450 = $98,100
- Unmapped: 246 × $270 = $66,420
- Unexpected Product: 94 × $100 = $9,400
- **Total: $3,399,070 investigation effort** - exceeds $50k threshold, triggers CCO escalation.

> **Confirmed Fact vs Risk Indicator split:** Complaint counts are facts; $ exposure is risk indicator based on analyst assumption.

### Responsible Owners & RACI

| Owner | Control | Exception Types | Due Days | Current Count |
|-------|---------|-----------------|----------|---------------|
| Compliance Ops Lead | CTRL-TIME-002 | Timely breach + Critical tier | 2 | 218 |
| Compliance Ops | CTRL-TIME-002 | Timely breach other tiers | 5 | 7,167 |
| Master Data Mgmt | CTRL-MAP-003 | Unmapped Entity | 2 | 246 |
| Product Risk Manager | CTRL-CONC-004 | Unexpected Product | 10 | 94 |
| Data Quality Team | CTRL-DQ-001 | Invalid dates filtered, missing zip | Daily | 371 missing zip (separate DQ log) |

### Status Workflow

- **Open** -> Auto-created when exception flagged
- **In Progress** -> Owner assigns and starts RCA (33% in sample marked In Progress for demo)
- **Pending Review** -> RCA done, waiting 2LOD approval
- **Closed** -> Remediation verified, control retest PASS
- **Escalated** -> P1 not acknowledged in 24h

System: Power BI alert → Power Automate → ServiceNow ticket with due_date.

### Recommended Actions (Examples)

1. **Timely Breach - Critical Tier:**
   - RCA: Was complaint routed correctly? Check ServiceNow queue for EQUIFAX complaints June 2023 >15 days.
   - Review staffing: 43% breach rate indicates systemic, not isolated.
   - Action: Increase compliance ops headcount or automate routing for Critical tier; implement SLA warning at day 10.
   - Due: 2026-07-12

2. **Unmapped Entity:**
   - Search external registry: UNKNOWN ENTITY 90xx LLC - is this a new fintech partnership?
   - If legitimate, create DimCompany entry, assign risk tier Medium pending risk assessment, backfill FactComplaints company_key.
   - If not legitimate, correct source mapping error.
   - Due: 2026-07-12

3. **Unexpected Product:**
   - Check CFPB release notes 2024: Did CFPB add Crypto wallet as official product?
   - If yes, update DimProduct master, set is_unexpected=FALSE, communicate to reporting team.
   - If no, data entry error - fix ETL product mapping.
   - Due: 2026-07-20

### Drill-Through Capability (Mandatory Component #7)

**Every executive KPI must connect to underlying:**

- **Company:** Click Exception Rate KPI bar for EQUIFAX -> filters to company
- **Transaction:** Not in this project, but transaction ID would be in FactTransactions extension (future)
- **Supplier:** DimCompany = supplier analog
- **Complaint:** Complaint ID drill-through page shows full narrative, timeline, flags
- **Facility:** Not applicable, but Geography drill to state/zip
- **Exception:** Exception type page lists rule breach detail
- **Control Owner:** Card shows owner per DimRisk.control_owner + email

Power BI Implementation:
- Page 1 Executive Summary KPI cards with drill-through buttons
- Right-click on any visual -> Drillthrough -> Complaint Detail (shows complaint_id, narrative, recommended action)
- Report `actionable_exceptions.csv` is generated from DAX query equivalent for paginated report export.

### Evidence

- Full actionable file: 7,725 rows, sorted by priority P1 first
- Top 10 P1 Critical: EQUIFAX 85 complaints, Experian 70, TRANSUNION 63 = 218 total
- Due date logic from today (2026-07-10) - all P1 overdue if not resolved by 2026-07-12

### Closure Criteria

- Timely breach: New control 10-day warning implemented + 7-day avg <5% breach rate for 2 consecutive weeks
- Unmapped: Zero unmapped entities in daily DQ check for 7 days
- Unexpected product: Product master updated + Product Risk sign-off
