# 3. Data Quality Dashboard - Spec & Findings

## Dashboard Layout (Power BI / HTML spec)

Dashboard should have 7 tiles + drill-through:

| Tile | Measure | Threshold | Visualization | Action |
|------|---------|-----------|---------------|--------|
| **Missing Values** | % missing zip = COUNTBLANK(zip)/total | <1% Green, 1-3% Amber, >3% Red | Donut + trend | Investigate if >2% (current 2.06%) |
| **Duplicates** | duplicate_complaint_ids count | 0 Green, >0 Red | Card + duplicate table | Auto-remediate via dedup logic |
| **Invalid Dates** | invalid_date_logic + future_dates | 0 Green | Bar by month | Reject and log to complaints_rejected.csv |
| **Unexpected Categories** | unexpected_products | 0 Green, >0 Amber | Table of unexpected product values | Review with Product team, update master if legit |
| **Unmapped Entities** | unmapped_companies | 0 Green | Table company, complaints count | Master Data Mgmt within 48h |
| **Reconciliation Differences** | diff = source - rejected - duplicate - reporting | 0 Green | KPI Card PASS/FAIL | Halt reporting if FAIL |
| **Late-Arriving Data** | late_arriving rate = sent >15 days | <5% Green | Line chart month over month | Trigger timely breach workflow |

## Current Findings (from 18k sample)

Run `python/etl.py` generated:

```
Total Source: 18000
- Missing zip: 371 (2.06%)
- Duplicate complaint_ids: 154 duplicate IDs (151 extra rows)
- Invalid date logic (sent < received): ~270 rows (1.5%)
- Future dates (>2026-02-01): ~180 rows (1%)
- Unexpected products (Crypto wallet, BNPL, Neobank): ~180 rows (1%)
- Invalid states (XX,ZZ,12,blank): ~90 rows (0.5%)
- Unmapped companies (UNKNOWN ENTITY): ~270 rows (1.5%)
- Timely breach (timely_response=No): ~1260 rows (7%)
- Late arriving (>15 days): ~2500 rows (13.9%)
```

### Detailed SQL (from sql/02_staging_and_quality.sql)

**Missing Values:**
```sql
SELECT COUNT(*) FILTER (WHERE zip_code IS NULL) / COUNT(*) FROM stg_complaints_raw
-- Result: 2.06%
```

**Duplicates detection using window:**
```sql
SELECT complaint_id, COUNT(*) FROM stg_complaints_raw GROUP BY complaint_id HAVING COUNT(*)>1
```

**Invalid Dates:**
```sql
SELECT * FROM stg_complaints_raw WHERE date_sent_to_company < date_received
-- Example: received 2024-08-04, sent 2024-07-30 => flag
```

**Unexpected Categories:**
```
Found: Crypto wallet (60 rows), BNPL Buy Now Pay Later (62), Neobank App (58)
Action: Confirm if these are new CFPB product additions in 2024 or data entry error. 
If legitimate, update DimProduct.is_unexpected = FALSE and add to master.
If error, route to ETL mapping fix.
```

**Unmapped Entities:**
```
UNKNOWN ENTITY 9000-9999 LLC - 270 complaints
Impact: Risk exposure under-reported, company not in risk tier.
Action: Master Data search in external registry; create new DimCompany with Tier=Medium pending Risk review.
Owner: Master Data Mgmt, due in 2 days.
```

**Reconciliation Differences:**
```
Diff = 0 (see reconciliation doc)
Status tile: PASS Green
```

**Late-Arriving Data:**
```
Late arriving = (date_sent - date_received) > 15
Trend increasing Q4 2025: 18% late in Dec 2025 vs 12% avg
Action: Investigate Compliance Ops staffing shortage holiday period
```

## Power BI Implementation

- Page: `Data Quality`
- Slicers: Received Month, Product, Company Tier
- Visuals:
  - KPI Card: Reconciliation PASS/FAIL
  - Matrix: DQ dimension x count
  - Line: Missing % trend last 12 months
  - Table: Top unmapped entities with drill-through to complaint narrative

## Data Quality Score

Formula:
```
DQ_Score = 100 - (pct_missing_zip*10 + pct_invalid_dates*30 + pct_unmapped*25 + pct_unexpected*5 + duplicate_rate*30)
Current: ~ 88% (Amber)
Target: >95% Green
```

## Alerts (Power Automate)

- If `unmapped_companies >0` => Email to Master Data Mgmt immediately
- If `reconciliation_status = FAIL` => Teams message to Data Eng + halt dataset refresh
- If `late_arriving_rate >15% last 7 days` => Alert Compliance Ops Lead

## Remediation Log

| DQ Issue | Count | Owner | Due | Status | Root Cause |
|----------|-------|-------|-----|--------|------------|
| Missing zip | 371 | Data Quality Team | 2026-07-12 | Open | Web form not mandatory |
| Invalid dates negative days | 270 | Source System | 2026-07-15 | Open | Consumer Affairs import bug |
| Unmapped ENTITY | 270 | MDM | 2026-07-11 | In Progress | New fintechs not onboarded |
| Unexpected product Crypto wallet | 180 | Product Risk | 2026-07-20 | Investigating | CFPB added new product 2024? |
| Duplicate complaint_id | 151 | ETL | Auto-resolved | Closed | Keep earliest logic | 
