# 6. Assumptions and Limitations - Clear Separation

This document explicitly separates **confirmed fact vs calculated KPI vs analyst assumption vs risk indicator vs confirmed exception** per mandatory component #9.

## Taxonomy Legend

- 🟢 **CONFIRMED FACT** - Directly from source, auditable, reconciliation PASS
- 🟡 **CALCULATED KPI** - Computed via deterministic logic from facts
- 🟠 **ANALYST ASSUMPTION** - Judgment/benchmark, should be What-If parametrized
- 🔴 **RISK INDICATOR** - Signal, not actual loss
- ⚠️ **CONFIRMED EXCEPTION** - Rule breach, requires investigation

---

### CONFIRMED FACTS (🟢)

| Fact | Source | Evidence |
|------|--------|----------|
| Complaint exists with ID, company, product, issue, dates | CFPB CCDB - https://files.consumerfinance.gov/ccdb/complaints.csv.zip | `data/raw/complaints_raw.csv` 18k sample, real schema |
| Source rows = 18000 | Raw file count | `python/generate_sample.py` + `reconciliation.json` |
| Rejected rows = 504 due to invalid date logic | ETL flag `dq_flag_invalid_dates` | `complaints_rejected.csv` |
| Duplicate removal = 151 rows, keep first per complaint_id ordered by date_received | Window ROW_NUMBER logic | SQL `02_staging_and_quality.sql` duplicate detection |
| Reporting rows = 17345 | FactComplaints.csv count | Reconciliation PASS diff 0 |
| Company names: EQUIFAX, Experian, TRANSUNION, BANK OF AMERICA etc | CFPB source list | DimCompany.csv 318 rows |
| Product categories: 8 CFPB standard products | CFPB taxonomy | DimProduct.csv |
| Date received between 2022-01-01 and 2025-12-31 | Source dates | DimDate min/max |
| Timely response field = Yes/No from CFPB | CFPB source | Raw column timely_response |

**Limitations of facts:** Sample only 18k vs production 5M+; no PII beyond zip; narrative only 35% have consent.

---

### CALCULATED KPIs (🟡)

| KPI | Formula | Confidence | Check |
|-----|---------|------------|-------|
| **Total Complaints** | COUNT(FactComplaints) | High | Reconciled |
| **Total Exceptions** | COUNT WHERE is_exception=TRUE | High | Rule: timely=No OR unmapped OR unexpected |
| **Exception Rate** | Exceptions / Total | High | DAX measure |
| **Rolling 12M Complaints** | SUM last 12 months window | High | SQL window ROWS 11 PRECEDING, DAX DATESINPERIOD |
| **YoY Change %** | (Current - SameMonthLastYear)/LastYear | High | LAG 12 months, SAMEPERIODLASTYEAR |
| **Avg Days to Company** | AVG(days_to_company) | High | Valid dates only |
| **Company Contribution %** | Company complaints / ALL complaints | High | DAX DIVIDE + ALL() |
| **Cumulative Contribution** | SUMX TOPN rank | Medium | Depends on rank logic |
| **Peer Percentile** | PERCENTRANKX of exception rate vs all companies | Medium | Requires peer group large enough |
| **Ranking** | RANKX exception count DESC | High | Window RANK() |
| **Ageing Buckets** | CASE days_to_company intervals | High | Custom buckets 0-1,2-5,6-15,16-30,30+ |
| **Concentration Top 3** | SUM Top 3 / Total | High | TOPN logic |
| **Herfindahl Index** | SUM(share^2) | Medium | Interpretation requires economics context |
| **Z-Score Anomaly** | (cnt - avg)/stddev | Medium | Threshold 2 stddev is arbitrary |
| **Late Arriving Rate** | Late >15 days / Total | High | |

**Limitations:** KPIs depend on correct SCD2 join and dedup logic. If logic changes, KPI history shifts. Peer percentile unstable for companies with <20 complaints (filtered).

---

### ANALYST ASSUMPTIONS (🟠)

| Assumption | Value Used | Rationale | Sensitivity | What-If Param |
|------------|------------|-----------|-------------|---------------|
| **Cost per complaint investigation** | $450 | Industry benchmark from CFPB enforcement reports + internal ops estimate (Compliance Ops) | Low-Medium - actual varies $100-$5000 per case complexity | Yes: Cost per Complaint slider $100-$5000, default $450 |
| **SLA Threshold** | 15 days | CFPB requirement, but internal could be stricter | High impact on exception count | Yes: SLA Threshold slider 1-30 days, default 15 |
| **Company Risk Tier** | Critical = EQUIFAX/Experian/TRANSUNION; High = BOA/CHASE/WELLS; else Medium | Judgment based on systemic importance + complaint volume | Medium - affects escalation priority | Documented in DimCompany generation logic, should be master data table in prod |
| **Region Mapping** | State -> West/South/Midwest/Northeast mapping | Standard US Census regions | Low impact | Could be enriched from external population data |
| **Severity Score per Issue** | Default 3, could be weighted | Not used in current KPI but available in DimIssue | Low - future use | - |
| **DQ Score Weights** | Missing zip ×10, invalid dates ×30, unmapped ×25 etc | Analyst weighting of DQ importance | Medium - affects DQ Score % | - |
| **Anomaly Threshold** | Z-Score >2 = anomaly | Standard statistical threshold | Medium - could be >3 for less noise | - |
| **Concentration Threshold** | >50% Top 3 = high concentration risk | 50% arbitrary, 80/20 rule inspired | Medium | What-If could vary |
| **Population enrichment** | Not included | Would need external census data | - | Future |

**Impact of assumptions:** Estimated exposure $765k uses $450 assumption; if true cost $2000, exposure $3.4M. Dashboard shows What-If so decision makers can test.

---

### RISK INDICATORS (🔴) - Not Confirmed Loss

| Indicator | Calculation | What it signals | What it does NOT mean |
|-----------|-------------|-----------------|-----------------------|
| **Estimated Exposure $** | Exceptions × Cost assumption | Potential investigation budget needed | Not actual regulatory fine or loss |
| **Concentration >50%** | Top 3 share | Risk of systemic product defect | Not proven defect, needs drill-through |
| **Peer Percentile >90th** | Company exception rate vs peers | Company worse than 90% of peers | Not legal liability, just comparative |
| **Z-Score Anomaly >2** | Statistical outlier vs avg | Unusual spike, maybe event | Not automatically incident, could be seasonality |
| **Exception Rate Trend Up** | Rolling 12M increasing 3 months | Deteriorating control | Not causation, needs RCA |
| **Late Arriving Increasing** | Month trend up | Operational capacity issue | Not confirmed understaffing |

**Usage guidance:** Risk indicators should trigger investigation, not conclusion. Always drill-through to complaint narrative and control owner.

---

### CONFIRMED EXCEPTIONS (⚠️)

These are **rule breaches**, not assumptions. They require investigation per workflow.

| Exception Type | Rule | Count in Sample | Owner | Severity |
|----------------|------|-----------------|-------|----------|
| **Timely Breach** | `timely_response = 'No'` OR `days_to_company > 15` | 1,248 (7.2%) | Compliance Ops | P1 if Critical Tier |
| **Unmapped Entity** | `company LIKE '%UNKNOWN ENTITY%'` OR NOT IN DimCompany master | 270 (1.5%) | Master Data Mgmt | P2 - blocks reporting |
| **Unexpected Product** | `product NOT IN approved CFPB list of 8` | 180 (1%) | Product Risk | P3 - taxonomy review |
| **Invalid Dates** | `date_sent < date_received` OR null OR future > today+30 | 504 (2.8%) | Data Eng/Source Sys | Rejected - not in reporting |
| **Duplicate Complaint ID** | Same complaint_id appears >1 | 151 extra rows | ETL Auto | Auto-remediated keep first |
| **Missing Zip** | zip IS NULL | 371 (2.06%) | Data Quality | P3 |
| **Invalid State** | state NOT IN US list | ~90 (0.5%) | Data Quality | P3 |

**Evidence:** `data/processed/complaints_quality_flagged.csv` has flag columns, `FactComplaints.csv` retains flags for dashboard.

**Escalation:** If any Critical Tier company has timely breach => P1 ticket + CCO notification.

---

### Overall Limitations Summary

1. **Sample vs Production:** 18k sample, CFPB real is 5M+. Scaling same logic works, but performance tuning needed (partitioning, incremental refresh). Template provided.
2. **No Transaction Link:** Requirement mentions FactTransactions but this project only has FactComplaints. Transaction linkage would strengthen root cause (e.g., did complaint follow failed transaction?). Future roadmap includes joining to core banking transactions.
3. **Narrative Limited:** Only 35% have narrative due to consent. NLP sentiment analysis possible but not robust with this coverage.
4. **No PII:** Zip only, no customer ID, cannot track repeat complainant.
5. **External Data Not Integrated:** Population for per-capita normalization, credit bureau market share for expected rate, etc. would improve peer percentile.
6. **SCD2 Demo Single Entity:** Only BANK OF AMERICA has SCD2 example; production would track all corporate actions.
7. **Cost Assumption Sensitivity:** Exposure $ highly sensitive to cost per case assumption - use What-If.
8. **Time Horizon:** Sample up to Dec 2025, today is July 2026, so not fully current. Production pipeline would be daily refresh.

**Sign-off:** Data Quality Team attests facts reconciled, assumptions documented and parametrized, exceptions confirmed and listed in actionable output.

