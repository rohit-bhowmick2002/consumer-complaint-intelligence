# 1. Business and Control Objective

## Consumer Complaint Intelligence Dashboard

### What decision does the dashboard support?

This dashboard supports **Consumer Compliance, Risk & Controls, and Customer Experience** leadership in deciding:

1. **Which companies, products, and geographies drive elevated consumer harm risk?**
2. **Where are we breaching CFPB timeliness controls (15-day SLA) and what is the regulatory exposure?**
3. **Which complaints require immediate investigation vs. quarterly trend monitoring?**
4. **Is complaint concentration a systemic product defect or isolated incidents?**
5. **Should we increase investigations staffing, update disclosures, or trigger product remediation?**

Specific decisions:
- Approve / reject new product rollout based on peer complaint percentile
- Prioritize audit of `EQUIFAX, INC.` vs `WELLS FARGO & COMPANY` based on exception rate and contribution %
- Allocate compliance ops budget using estimated exposure $ (exceptions × cost per case What-If)
- Trigger Material Consumer Complaint escalation if rolling 12M breaches threshold

### Who uses it?

| Persona | Role | Usage Frequency | KPI Focus |
|---------|------|-----------------|-----------|
| **CCO / Chief Compliance Officer** | Final owner of Consumer Complaint Risk | Weekly | Exception Rate, YoY change, Concentration, Estimated Exposure |
| **Compliance Ops Lead** | Manages timely response SLA | Daily | Timely Response Rate, Ageing Buckets, Late-Arriving % |
| **Risk & Controls (2LOD)** | Validates control effectiveness | Weekly | Control break count by CTRL-ID, Reconciliation differences, Unmapped entities |
| **Product Risk Manager** | Owns product-specific complaint trends | Weekly | Product Contribution %, Peer Percentile, Issue Drill |
| **Data Quality Team** | Ensures source-to-report integrity | Daily | DQ Dashboard: missing zip, duplicate, invalid dates, unexpected categories |
| **Internal Audit** | Reconciliation & lineage check | Monthly | Source-to-report table, Slowly Changing Dimension history |

### What happens when an exception appears?

**Exception definition:** `timely_flag=0` OR `dq_flag_unmapped_company=TRUE` OR `dq_flag_unexpected_product=TRUE` OR `days_to_company > 15` (breach of CFPB requirement)

**Workflow when exception detected (automated in Power BI + ServiceNow):**

```
Exception flagged in FactComplaints.is_exception = TRUE
    |
    ├─> Real-time alert (Power Automate) to Control Owner per DimRisk.control_owner
    |     Risk Key 2 (Timeliness Breach) -> Compliance Ops
    |     Risk Key 3 (Unmapped Entity) -> Master Data Mgmt
    |     Risk Key 1 (Data Integrity) -> Data Quality Team
    |     Risk Key 4 (High Concentration) -> Risk & Controls
    |
    ├─> Auto-create JIRA/ServiceNow ticket:
    |     Title: [P1] Timely Breach - Company: BANK OF AMERICA, Complaint ID: 7001234
    |     SLA: 48 hours investigation, 5 business days remediation plan
    |
    ├─> Drill-through mandatory:
    |     Executive KPI -> Company -> Transaction -> Complaint Narrative -> Control Owner
    |
    └─> Escalation:
          If exception_rate > 8% for Critical Tier company (EQUIFAX, Experian, TRANSUNION)
          OR estimated exposure > $50k in rolling 12M
          => Escalate to CCO + trigger Material Risk Event log
```

**SLA for actions:**
- P1 (Critical Tier + timely breach): 24h acknowledgment, 3 day closure
- P2 (High Tier + unmapped): 48h acknowledgment, 7 day closure
- P3 (Data Quality): 5 day closure

### Which risk or control does it address?

Mapped to Enterprise Risk Framework:

| Risk ID | Risk Description | Control ID | Control Description | How dashboard tests control |
|---------|------------------|------------|---------------------|-----------------------------|
| RISK-CONS-01 | Failure to respond to consumer complaints within regulatory 15-day window | CTRL-TIME-002 | Automated SLA tracking + daily exception report | `FactComplaints.timely_flag` + Ageing Bucket + Late Arriving Rate measure. Threshold: >5% breach rate = control ineffective |
| RISK-DATA-02 | Incomplete / inaccurate regulatory reporting to CFPB | CTRL-DQ-001 | Source-to-report reconciliation + DQ dashboard | Reconciliation equation checked daily; DQ Score <95% triggers halt to reporting |
| RISK-MASTER-03 | Unmapped counterparty leads to under-reported exposure | CTRL-MAP-003 | Master data validation against DimCompany | `dq_flag_unmapped_company` + Unmapped Entities KPI. Zero tolerance. |
| RISK-PROD-04 | Undetected systemic product defect via complaint concentration | CTRL-CONC-004 | Herfindahl Index + Top 3 concentration monitoring | Concentration >50% triggers product deep dive. Peer percentile >90th = high risk. |
| RISK-AUDIT-05 | Inability to reconstruct history due to SCD not tracked | CTRL-SCD-005 | SCD2 tracking for DimCompany | DimCompany effective_from/to + is_current; Fact join uses BETWEEN logic; audit trail retained |

**Regulatory mapping:**
- CFPB Regulation: 12 CFR § 1024.35 (Mortgage servicing), 12 CFR § 1022.43 (Credit reporting dispute)
- Internal Policy: Consumer Complaint Management Standard v3.2

**Control effectiveness statement:**
If `reconciliation_pass = TRUE` AND `timely_breach_rate < 5%` AND `unmapped_entities = 0`, then controls are **Effective**. Otherwise **Ineffective - Requires Remediation**.
