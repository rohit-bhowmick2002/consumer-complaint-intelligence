# 2. Source-to-Report Reconciliation

This document proves auditability from CFPB source landing to final reporting fact.

## Real Source
- **Primary URL:** https://files.consumerfinance.gov/ccdb/complaints.csv.zip
- **API:** https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/
- **Fields reference:** https://cfpb.github.io/api/ccdb/fields.html
- **Local raw sample used for portfolio demo:** `data/raw/complaints_raw.csv` - 18,000 rows mimicking production schema with intentional quality flaws for demonstration.

## Equation (Text Format Required)

```
Source rows
− rejected rows (invalid dates: null OR sent < received OR future > today+30)
− duplicate treatment (keep first per complaint_id ordered by date_received)
± transformations (date_key enrichment, risk scoring, hash, SCD2 company join, flag retention)
= reporting rows
```

## Actual Run (Latest)

From `data/processed/reconciliation.json`:

```json
{
  "source_rows": 18000,
  "rejected_invalid_dates": 504,
  "duplicate_removed": 151,
  "transformations_added": [
    "date_key enrichment",
    "risk scoring",
    "hash keys"
  ],
  "reporting_rows": 17345,
  "equation_check": "18000 - 504 - 151 - 0 transformed = 17345",
  "reconciliation_pass": true
}
```

**Math:**
```
18000 - 504 = 17496
17496 - 151 = 17345
17345 + 0 transformation delta (transformations do not add/remove rows, only enrich) = 17345
Reporting = 17345
Diff = 0 => PASS
```

## Reconciliation Logs

| Layer | Count | Logic |
|-------|-------|-------|
| **Source** | 18,000 | `SELECT COUNT(*) FROM stg_complaints_raw` |
| **Rejected** | 504 | `date_sent < date_received` OR null dates OR future > 2026-02-01 (2.8% reject rate) |
| **After Invalid Filter** | 17,496 | Source - Rejected |
| **Duplicate Extra** | 151 | `ROW_NUMBER() PARTITION BY complaint_id ORDER BY date_received`, keep rn=1. Duplicate rate 0.86% |
| **FactComplaints** | 17,345 | Final reporting grain: 1 row = 1 unique complaint |
| **Check** | 18,000 | Rejected + Duplicate + Fact = 504+151+17345 = 18000 => PASS |

## Transformation Inventory (±)

These do NOT change row count, but are auditable:

| Transformation | Type | Audit Check |
|----------------|------|-------------|
| `date_key_received = TO_CHAR(date_received,'YYYYMMDD')` | Enrichment | FK to DimDate must exist |
| `days_to_company = date_sent - date_received` | Calculation | Range -1 to 100, negative flagged as invalid |
| `risk_key = CASE WHEN company LIKE '%UNKNOWN%' THEN 3 WHEN timely='No' THEN 2 ELSE 4` | Risk Scoring | Join to DimRisk |
| `complaint_hash = MD5(complaint_id)` | Hash for lineage | Unique per complaint_id |
| `company_key join via SCD2 BETWEEN effective_from and effective_to` | Dimensionalization | Current flag logic avoids fan-out |
| `Flag retention: dq_flag_missing_zip, dq_flag_unexpected_product, etc` | DQ retention | Kept in fact for dashboard, not filtered |

## SQL Proof (see sql/05_reconciliation.sql)

```sql
WITH stats AS (
    SELECT COUNT(*) AS src,
           COUNT(*) FILTER (WHERE date_sent < date_received OR date_received IS NULL) AS rej
    FROM stg_complaints_raw
)
SELECT src - rej - (after_reject - final_fact) = final_fact AS pass
```

**Evidence files:**
- `data/processed/complaints_quality_flagged.csv` - 18000 rows with all dq flags
- `data/processed/complaints_rejected.csv` - 504 rows rejected
- `data/processed/complaints_clean.csv` - 17345 after dedup
- `data/processed/FactComplaints.csv` - 17345 final
- `data/processed/reconciliation.json` - machine-readable
- `sql/05_reconciliation.sql` - audit table `audit_reconciliation`

## Control Attestation

> I confirm totals reconcile to original source within 0 diff. No silent row loss. Duplicate treatment logic is deterministic (keep earliest). Rejected rows are logged with reason.

**Owner:** Data Quality Team | **Date:** 2026-07-10 | **Status:** PASS
