# 4. Proper Data Model - Star Schema

## Why Star Schema?

- Fact grain is **1 row = 1 unique consumer complaint** after deduplication (confirmed fact)
- Dimensions are conformed for drill-through: Company, Product, Geography, Date, Issue, Risk
- Supports Power BI performance (relationships, DAX)
- Enables SCD2 for company merger tracking (regulatory requirement)

## Architecture Diagram (Mermaid)

```mermaid
erDiagram
    FactComplaints ||--o{ DimDate : "date_key_received -> date_key"
    FactComplaints ||--o{ DimDate : "date_key_sent -> date_key (role playing)"
    FactComplaints ||--o{ DimCompany : "company_key"
    FactComplaints ||--o{ DimProduct : "product_key"
    FactComplaints ||--o{ DimGeography : "geography_key"
    FactComplaints ||--o{ DimIssue : "issue_key"
    FactComplaints ||--o{ DimRisk : "risk_key"

    FactComplaints {
        BIGINT complaint_id PK
        INT date_key_received FK
        INT date_key_sent FK
        INT company_key FK
        INT product_key FK
        INT geography_key FK
        INT issue_key FK
        INT risk_key FK
        INT days_to_company
        INT timely_flag
        INT has_narrative_flag
        BOOLEAN is_exception
        BOOLEAN dq_flag_missing_zip
        BOOLEAN dq_flag_unexpected_product
        BOOLEAN dq_flag_unmapped_company
        BOOLEAN dq_flag_late_arriving
        VARCHAR complaint_hash
    }

    DimDate {
        INT date_key PK
        DATE full_date
        INT year
        INT quarter
        INT month
        VARCHAR month_name
        INT day
        INT day_of_week
        BOOLEAN is_weekend
    }

    DimCompany {
        INT company_key PK
        VARCHAR company
        VARCHAR company_clean
        VARCHAR company_risk_tier
        DATE effective_from
        DATE effective_to
        BOOLEAN is_current
        INT scd_version
    }

    DimProduct {
        INT product_key PK
        VARCHAR product
        VARCHAR sub_product
        VARCHAR product_category
        BOOLEAN is_unexpected
    }

    DimGeography {
        INT geography_key PK
        CHAR state
        VARCHAR zip_code
        VARCHAR region
        BOOLEAN is_valid_state
    }

    DimIssue {
        INT issue_key PK
        VARCHAR issue
        VARCHAR sub_issue
        INT severity_score
    }

    DimRisk {
        INT risk_key PK
        VARCHAR risk_category
        INT risk_score
        VARCHAR control_id
        VARCHAR control_owner
    }
```

## Table Details & Row Counts (from processed folder)

| Table | Rows | Grain | Description |
|-------|------|-------|-------------|
| **DimDate** | ~1,460 | 1 day | Calendar from 2022-01-01 to 2026-01-31, covers received and sent dates |
| **DimCompany** | 318 | 1 row per company version (SCD2 adds 1 extra) | 100+ distinct companies, risk tier: Critical (bureau), High (big banks), Medium (others) |
| **DimProduct** | ~ 30 | product+sub_product distinct | 8 products, multiple sub-products, unexpected flag for Crypto/BNPL |
| **DimGeography** | ~ 9,500 | state+zip distinct | US states + region mapping West/South/Northeast/Midwest |
| **DimIssue** | ~ 80 | issue+sub_issue distinct | Consumer harm taxonomy |
| **DimRisk** | 4 | risk_key | Maps to control framework |
| **FactComplaints** | 17,345 | 1 complaint | All quality flags retained |

## Star Schema Justification per Requirement

Requirement said:
```
FactTransactions
FactComplaints
FactAwards
FactEmissions

DimDate
DimCompany
DimSupplier
DimProduct
DimGeography
DimRisk
```

For Consumer Complaint Intelligence, we implement:
- **FactComplaints** = central fact (1 row = 1 complaint)
- **FactTransactions** equivalent could be linked if we added financial transaction data (future extension noted in limitations)
- **DimCompany** = financial institution complained about
- **DimProduct** = financial product
- **DimGeography** = consumer location
- **DimRisk** = risk/control mapping
- **DimDate** = role-playing dimension for received and sent dates
- **DimSupplier** not applicable, but DimCompany covers counterparty (documented in assumptions)

## Relationship Cardinality (Power BI)

- DimDate 1:* FactComplaints (both received and sent via inactive relationship + USERELATIONSHIP DAX)
- DimCompany 1:* FactComplaints (current logic: filter is_current for fact, but full SCD2 table kept for history)
- DimProduct 1:* FactComplaints
- DimGeography 1:* FactComplaints
- DimIssue 1:* FactComplaints
- DimRisk 1:* FactComplaints

All dimensions filter FactComplaints (single direction).

## SCD2 Implementation

**Type 2 example - BANK OF AMERICA:**

| company_key | company | effective_from | effective_to | is_current | scd_version |
|-------------|---------|----------------|--------------|------------|-------------|
| 82 | BANK OF AMERICA... | 2022-01-01 | 2023-06-30 | FALSE | 1 |
| 319 | BANK OF AMERICA... (NEW ENTITY) | 2023-07-01 | 9999-12-31 | TRUE | 2 |

**Join logic for fact:**
```sql
JOIN DimCompany dc ON dc.company = c.company 
  AND c.date_received BETWEEN dc.effective_from AND dc.effective_to
```
This ensures complaints before merger point to old entity version, after to new.

**Audit query:**
```sql
SELECT * FROM DimCompany WHERE company ILIKE '%BANK OF AMERICA%' ORDER BY effective_from;
```

## Performance Considerations

- `FactComplaints` partitioned by `date_key_received` year in warehouse (not in CSV demo but DDL comment)
- Indexes on `company_key`, `product_key`, `is_exception` filtered index
- `complaint_hash` for lineage tracing without exposing PII
- `DimGeography` could be snowflaked to DimZip but kept flat for Power BI simplicity

## Data Lineage

```
CFPB CCDB (CSV/ZIP - 5M+ rows in prod, 18k sample in demo)
    -> stg_complaints_raw (18k)
    -> complaints_quality_flagged (18k with flags)
    -> complaints_rejected (504 invalid) + complaints_clean deduplicated (17345)
    -> Dimensions (SCD2, etc) + FactComplaints (17345)
    -> Power BI dataset: 6 dims + 1 fact = 17,345 rows final
```

## Power BI Model File

Spec in `powerbi/dashboard_spec.md` defines relationships. In actual `.pbix`, load CSVs from `data/processed/`.

## Extension Points

- `FactTransactions` could join on `company_key` + `DimGeography` if we ingest CC transaction data (future roadmap)
- `FactEmissions` analog = `FactNarrativeSentiment` if we run NLP on complaint narratives
