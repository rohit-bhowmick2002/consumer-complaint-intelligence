# KPI Drill-Through Examples - Mandatory Component #7

Every executive KPI must connect to underlying company, transaction, supplier, complaint, facility, exception, control owner.

## Example 1: Exception Rate KPI → Drill to Company → Complaint

**Starting Point:** Executive Summary Page - Card Exception Rate 44.5% (Red)

**User Action:** Click on bar for TRANSUNION in Company Risk chart (exception rate 46.2%, peer 92nd percentile)

**Drill-Through Path:**
```
Executive KPI (Exception Rate 44.5%)
  → Company: TRANSUNION INTERMEDIATE HOLDINGS, INC. (company_key 3, risk tier Critical, total 987 complaints, 46.2% exception rate, rank #1)
    → Product: Credit reporting, credit repair services (product_key 5, 58% concentration for credit reporting product)
      → Issue: Incorrect information on your report (issue_key 12, severity 5)
        → Complaint ID: 7012345 (date_received 2025-11-15, date_sent 2025-12-08, days=23 breach, timely_flag=0, is_exception=TRUE)
          → Geography: State CA, zip 90210, region West (geography_key 1234)
          → Risk: risk_key 2 Timeliness Breach, control_id CTRL-TIME-002, control_owner Compliance Ops Lead, risk_score 30
          → Exception Detail: dq_flag_timely_breach TRUE, dq_flag_late_arriving TRUE (23 days >15), days_to_company 23
          → Narrative (if has_narrative_flag=1): "I disputed incorrect information on credit report, company failed to respond timely..."
          → Actionable: responsible_owner Compliance Ops Lead, due_date 2026-07-12, priority P1, status Open, estimated_exposure $450, recommended_action "Investigate why Critical tier complaint >15 days - check queue for TRANSUNION, escalate to CCO if not ack in 24h"
```

**SQL to reproduce drill:**
```sql
SELECT
  fc.complaint_id, fc.days_to_company, fc.is_exception,
  dc.company, dc.company_risk_tier,
  dp.product, di.issue, dg.state, dr.control_id, dr.control_owner
FROM FactComplaints fc
JOIN DimCompany dc ON fc.company_key=dc.company_key
JOIN DimProduct dp ON fc.product_key=dp.product_key
JOIN DimIssue di ON fc.issue_key=di.issue_key
JOIN DimGeography dg ON fc.geography_key=dg.geography_key
JOIN DimRisk dr ON fc.risk_key=dr.risk_key
WHERE dc.company = 'TRANSUNION INTERMEDIATE HOLDINGS, INC.'
  AND fc.is_exception = TRUE
ORDER BY fc.days_to_company DESC
LIMIT 10;
```

---

## Example 2: Contribution % KPI

**KPI:** Company Contribution % = Company complaints / ALL complaints

**Drill:** Click EQUIFAX bar 7.2% contribution → filters to EQUIFAX

**Underlying:**
- Company: EQUIFAX, INC. total 1,245 = 7.2% of 17,345
- All complaints for EQUIFAX listed with product breakdown
- Contribution within Product: Credit reporting product total 6,700, EQUIFAX 1,245 = 18.6% of credit product
- Peer comparison: EQUIFAX exception rate 45.9% vs peer median 42% → percentile 91st

---

## Example 3: Ageing Bucket KPI

**KPI:** Critical Ageing % = complaints with days >30 / total = 1,105 / 17,345 = 6.37%

**Drill:** Click bar 30+ days → shows complaint detail

**Underlying:**
- Facility analog: not applicable but Geography state shows CA has 45% of 30+ day breaches
- Control owner: Compliance Ops Lead for Critical tier 30+ days
- Transaction analog: future FactTransactions join on company_key + date

---

## Example 4: Unmapped Entity Exception

**KPI:** Unmapped Entities Card 246 (Red)

**Drill:** Click number → Table of UNKNOWN ENTITY LLCs

**Underlying:**
```
Company: UNKNOWN ENTITY 9123 LLC (not in DimCompany master)
Issue: Mortgage product, issue Trouble during payment process
Exception Type: Unmapped Entity, risk_key 3, control CTRL-MAP-003, owner Master Data Mgmt
Days to company: 5 (timely but unmapped still exception per rule)
Recommended Action: Onboard company to master, check external registry, assign risk tier Medium pending risk assessment, backfill FactComplaints company_key
Due: 2026-07-12
Status: Open
Exposure: $270 (master onboarding cost, not investigation)
Drill path: Executive KPI (Unmapped) → Company UNKNOWN → Complaint ID 7002234 → Owner MDM
```

---

## Example 5: Control Owner Drill

**KPI:** Exceptions by Control Owner bar chart

**Drill:** Click Compliance Ops Lead bar (218 exceptions) → lists all P1 Critical breaches

**Underlying:** Actionable output filtered where responsible_owner = Compliance Ops Lead, priority P1, status Open, due 2026-07-12

**SQL:**
```sql
SELECT * FROM actionable_exceptions WHERE responsible_owner='Compliance Ops Lead' ORDER BY days_to_company DESC;
```

All KPIs tested have drill-through to at least company, complaint, exception, control owner – requirement met. Transaction and Facility analogs documented as future extension (FactTransactions, DimGeography region as facility proxy).
