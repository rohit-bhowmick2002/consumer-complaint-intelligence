
| Check | Count | % | Status |
|-------|-------|---|--------|
| Missing zip | 371 | 2.06% | AMBER |
| Duplicates | 306 | 1.7% | AUTO-FIXED |
| Invalid dates | 504 | 2.8% | REJECTED |
| Unexpected product | 175 | 0.97% | REVIEW |
| Invalid state | 93 | 0.52% | FLAGGED |
| Unmapped company | 258 | 1.43% | BLOCK |
| Timely breach | 7765 | 43.14% | BREACH |
| Late arriving >15d | 7011 | 38.95% | BREACH |
| DQ Score | - | 81.41% | Amber |
