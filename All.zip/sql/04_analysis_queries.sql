-- =============================================================
-- 04 - Analytical Queries - Business KPIs
-- Demonstrates: CTEs, window functions, conditional aggregation,
--               rolling calcs, ranking, period comparisons
-- =============================================================

-- -------------------------------------------------------------
-- 1. KPI BASE - Exception Rate by Company (conditional agg + ranking)
-- -------------------------------------------------------------
WITH company_stats AS (
    SELECT
        dc.company,
        dc.company_risk_tier,
        COUNT(*) AS total_complaints,
        SUM(CASE WHEN fc.is_exception THEN 1 ELSE 0 END) AS exception_count,
        SUM(CASE WHEN fc.timely_flag=0 THEN 1 ELSE 0 END) AS untimely_count,
        AVG(fc.days_to_company) AS avg_days_to_company,
        -- conditional aggregation
        SUM(CASE WHEN fc.dq_flag_unmapped_company THEN 1 ELSE 0 END) AS unmapped_cnt,
        SUM(CASE WHEN fc.dq_flag_unexpected_product THEN 1 ELSE 0 END) AS unexpected_product_cnt
    FROM FactComplaints fc
    JOIN DimCompany dc ON fc.company_key = dc.company_key
    GROUP BY dc.company, dc.company_risk_tier
)
SELECT
    company,
    company_risk_tier,
    total_complaints,
    exception_count,
    ROUND(exception_count*100.0/total_complaints,2) AS exception_rate_pct,
    untimely_count,
    ROUND(avg_days_to_company,2) AS avg_days,
    RANK() OVER (ORDER BY exception_count DESC) AS rank_exceptions_desc,
    RANK() OVER (ORDER BY total_complaints DESC) AS rank_volume_desc,
    PERCENT_RANK() OVER (ORDER BY exception_count*1.0/total_complaints) AS peer_percentile_exception_rate
FROM company_stats
WHERE total_complaints >= 50
ORDER BY exception_rate_pct DESC
LIMIT 20;

-- -------------------------------------------------------------
-- 2. ROLLING 12 MONTH - Complaint volume & YoY
-- -------------------------------------------------------------
WITH monthly AS (
    SELECT
        dd.year,
        dd.month,
        dd.year*100 + dd.month AS year_month,
        COUNT(*) AS complaints
    FROM FactComplaints fc
    JOIN DimDate dd ON fc.date_key_received = dd.date_key
    GROUP BY dd.year, dd.month
),
rolling AS (
    SELECT
        year,
        month,
        year_month,
        complaints,
        -- rolling 12 month
        SUM(complaints) OVER (ORDER BY year_month ROWS BETWEEN 11 PRECEDING AND CURRENT ROW) AS rolling_12m,
        AVG(complaints) OVER (ORDER BY year_month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS rolling_3m_avg,
        -- YoY comparison - same month last year
        LAG(complaints,12) OVER (ORDER BY year_month) AS complaints_same_month_last_year,
        LAG(SUM(complaints) OVER (ORDER BY year_month ROWS BETWEEN 11 PRECEDING AND CURRENT ROW),12) OVER (ORDER BY year_month) AS rolling_12m_last_year
    FROM monthly
)
SELECT
    year_month,
    complaints,
    rolling_12m,
    rolling_3m_avg,
    complaints_same_month_last_year,
    complaints - complaints_same_month_last_year AS yoy_change_abs,
    ROUND((complaints - complaints_same_month_last_year)*100.0 / NULLIF(complaints_same_month_last_year,0),2) AS yoy_change_pct,
    rolling_12m - rolling_12m_last_year AS rolling_yoy_change
FROM rolling
ORDER BY year_month DESC;

-- -------------------------------------------------------------
-- 3. CONCENTRATION ANALYSIS - Does top 5 companies drive >50%?
-- Demonstrates: window sum + contribution %
-- -------------------------------------------------------------
WITH company_vol AS (
    SELECT dc.company, COUNT(*) AS cnt
    FROM FactComplaints fc
    JOIN DimCompany dc ON fc.company_key = dc.company_key
    GROUP BY dc.company
),
total AS (SELECT SUM(cnt) AS total_cnt FROM company_vol),
ranked AS (
    SELECT
        company,
        cnt,
        cnt*100.0/(SELECT total_cnt FROM total) AS contribution_pct,
        SUM(cnt*100.0/(SELECT total_cnt FROM total)) OVER (ORDER BY cnt DESC ROWS UNBOUNDED PRECEDING) AS cumulative_pct,
        ROW_NUMBER() OVER (ORDER BY cnt DESC) AS rn
    FROM company_vol
)
SELECT * FROM ranked WHERE cumulative_pct <= 80 OR rn <= 10
ORDER BY cnt DESC;

-- -------------------------------------------------------------
-- 4. AGEING BUCKETS - How long complaints stay unresolved?
-- -------------------------------------------------------------
SELECT
    CASE
        WHEN days_to_company BETWEEN 0 AND 1 THEN '0-1 days (Immediate)'
        WHEN days_to_company BETWEEN 2 AND 5 THEN '2-5 days (Quick)'
        WHEN days_to_company BETWEEN 6 AND 15 THEN '6-15 days (Within SLA)'
        WHEN days_to_company BETWEEN 16 AND 30 THEN '16-30 days (Breached SLA)'
        ELSE '30+ days (Critical Breach)'
    END AS ageing_bucket,
    COUNT(*) AS complaint_count,
    COUNT(*) FILTER (WHERE is_exception) AS exception_in_bucket,
    ROUND(COUNT(*) FILTER (WHERE is_exception)*100.0/COUNT(*),2) AS exception_rate_in_bucket,
    ROUND(AVG(days_to_company),2) AS avg_days
FROM FactComplaints
GROUP BY 1
ORDER BY MIN(days_to_company);

-- -------------------------------------------------------------
-- 5. PEER PERCENTILE - Exception rate vs peer group (product category)
-- -------------------------------------------------------------
WITH product_company AS (
    SELECT dp.product_category, dc.company, COUNT(*) AS total, SUM(CASE WHEN fc.is_exception THEN 1 ELSE 0 END) AS exc
    FROM FactComplaints fc
    JOIN DimProduct dp ON fc.product_key = dp.product_key
    JOIN DimCompany dc ON fc.company_key = dc.company_key
    GROUP BY dp.product_category, dc.company
),
with_rate AS (
    SELECT *, exc*100.0/total AS exc_rate FROM product_company WHERE total>=20
)
SELECT
    product_category,
    company,
    total,
    exc_rate,
    PERCENT_RANK() OVER (PARTITION BY product_category ORDER BY exc_rate) AS peer_percentile,
    CUME_DIST() OVER (PARTITION BY product_category ORDER BY exc_rate) AS cume_dist,
    NTILE(4) OVER (PARTITION BY product_category ORDER BY exc_rate) AS quartile
FROM with_rate
ORDER BY product_category, exc_rate DESC;

-- -------------------------------------------------------------
-- 6. GEOGRAPHIC HOTSPOTS - State level rolling & anomaly
-- -------------------------------------------------------------
WITH state_month AS (
    SELECT dg.state, dd.year, dd.month, COUNT(*) AS cnt
    FROM FactComplaints fc
    JOIN DimGeography dg ON fc.geography_key = dg.geography_key
    JOIN DimDate dd ON fc.date_key_received = dd.date_key
    WHERE dg.state IS NOT NULL AND dg.is_valid_state
    GROUP BY dg.state, dd.year, dd.month
),
state_avg AS (
    SELECT state, AVG(cnt) AS avg_monthly, STDDEV(cnt) AS stddev_monthly
    FROM state_month GROUP BY state
)
SELECT
    sm.state,
    sm.year,
    sm.month,
    sm.cnt,
    sa.avg_monthly,
    sa.stddev_monthly,
    (sm.cnt - sa.avg_monthly)/NULLIF(sa.stddev_monthly,0) AS z_score,
    CASE WHEN ABS((sm.cnt - sa.avg_monthly)/NULLIF(sa.stddev_monthly,0)) > 2 THEN 'Anomaly' ELSE 'Normal' END AS status
FROM state_month sm
JOIN state_avg sa ON sm.state = sa.state
WHERE sm.year = 2025
ORDER BY z_score DESC
LIMIT 50;

-- -------------------------------------------------------------
-- 7. ISSUE DRILL - What issues drive exceptions?
-- -------------------------------------------------------------
SELECT
    dp.product,
    di.issue,
    COUNT(*) AS total,
    SUM(CASE WHEN fc.is_exception THEN 1 ELSE 0 END) AS exceptions,
    ROUND(SUM(CASE WHEN fc.is_exception THEN 1 ELSE 0 END)*100.0/COUNT(*),2) AS exception_rate,
    ROUND(AVG(fc.days_to_company),2) AS avg_days
FROM FactComplaints fc
JOIN DimProduct dp ON fc.product_key = dp.product_key
JOIN DimIssue di ON fc.issue_key = di.issue_key
GROUP BY dp.product, di.issue
HAVING COUNT(*) >= 100
ORDER BY exception_rate DESC
LIMIT 20;
