-- =============================================================
-- 05 - Source to Report Reconciliation Detail
-- Must pass audit: Source rows - rejected - duplicate = reporting
-- =============================================================

-- Full lineage table
DROP TABLE IF EXISTS audit_reconciliation;
CREATE TABLE audit_reconciliation (
    run_id VARCHAR(50),
    run_timestamp TIMESTAMP,
    source_file VARCHAR(200),
    source_rows BIGINT,
    rejected_rows BIGINT,
    rejected_reason VARCHAR(500),
    duplicate_treatment BIGINT,
    duplicate_logic VARCHAR(500),
    transformation_notes TEXT,
    reporting_rows BIGINT,
    diff BIGINT,
    status VARCHAR(10)
);

INSERT INTO audit_reconciliation
WITH stats AS (
    SELECT
        COUNT(*) AS src,
        COUNT(*) FILTER (WHERE date_sent_to_company < date_received OR date_received IS NULL OR date_sent_to_company IS NULL OR date_sent_to_company > CURRENT_DATE) AS rej,
        COUNT(*) - COUNT(DISTINCT complaint_id) AS dup_before_cleaning
    FROM stg_complaints_raw
),
cleaned AS (
    SELECT COUNT(*) AS after_reject FROM stg_complaints_raw
    WHERE NOT (date_sent_to_company < date_received OR date_received IS NULL OR date_sent_to_company IS NULL OR date_sent_to_company > CURRENT_DATE)
),
dedup AS (
    SELECT COUNT(*) AS final_fact FROM FactComplaints
)
SELECT
    MD5(NOW()::TEXT) AS run_id,
    NOW() AS run_timestamp,
    'complaints.csv from CFPB CCDB + local sample 18000 rows' AS source_file,
    s.src AS source_rows,
    s.rej AS rejected_rows,
    'Invalid dates: null or sent < received or future > today+30d' AS rejected_reason,
    c.after_reject - d.final_fact AS duplicate_treatment,
    'ROW_NUMBER PARTITION BY complaint_id ORDER BY date_received ASC, keep rn=1' AS duplicate_logic,
    'Added date_keys, risk scoring, hash, SCD2 join for company, flags retained' AS transformation_notes,
    d.final_fact AS reporting_rows,
    (s.src - s.rej - (c.after_reject - d.final_fact) - d.final_fact) AS diff,
    CASE WHEN (s.src - s.rej - (c.after_reject - d.final_fact)) = d.final_fact THEN 'PASS' ELSE 'FAIL' END AS status
FROM stats s, cleaned c, dedup d;

SELECT * FROM audit_reconciliation ORDER BY run_timestamp DESC LIMIT 5;

-- Second check: row level reconciliation - which source rows didn't make it?
WITH rejected AS (
    SELECT complaint_id, 'Invalid date logic' AS reason FROM stg_complaints_raw
    WHERE date_sent_to_company < date_received OR date_received IS NULL OR date_sent_to_company IS NULL
),
duped AS (
    SELECT complaint_id FROM (
        SELECT complaint_id, ROW_NUMBER() OVER (PARTITION BY complaint_id ORDER BY date_received) AS rn
        FROM stg_complaints_raw
        WHERE NOT (date_sent_to_company < date_received OR date_received IS NULL OR date_sent_to_company IS NULL)
    ) t WHERE rn > 1
)
SELECT 'Source' AS layer, COUNT(*) FROM stg_complaints_raw
UNION ALL
SELECT 'Rejected - invalid', COUNT(*) FROM rejected
UNION ALL
SELECT 'Duplicate extra', COUNT(*) FROM duped
UNION ALL
SELECT 'Fact Reporting', COUNT(*) FROM FactComplaints
UNION ALL
SELECT 'Check SUM', (SELECT COUNT(*) FROM FactComplaints) + (SELECT COUNT(*) FROM rejected) + (SELECT COUNT(*) FROM duped)
;
