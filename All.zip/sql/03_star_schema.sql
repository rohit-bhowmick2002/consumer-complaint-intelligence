-- =============================================================
-- 03 - Star Schema Population (SCD2 example)
-- Demonstrates: Slowly Changing Dimensions Type 2
-- =============================================================

-- DimDate population (from min to max date)
INSERT INTO DimDate (date_key, full_date, year, quarter, month, month_name, day, day_of_week, is_weekend)
WITH date_spine AS (
    SELECT generate_series(
        (SELECT MIN(date_received)::date FROM stg_complaints_raw),
        (SELECT MAX(date_sent_to_company)::date FROM stg_complaints_raw),
        interval '1 day'
    )::date AS full_date
)
SELECT
    TO_CHAR(full_date,'YYYYMMDD')::INT AS date_key,
    full_date,
    EXTRACT(YEAR FROM full_date)::INT AS year,
    EXTRACT(QUARTER FROM full_date)::INT AS quarter,
    EXTRACT(MONTH FROM full_date)::INT AS month,
    TO_CHAR(full_date,'Month') AS month_name,
    EXTRACT(DAY FROM full_date)::INT AS day,
    EXTRACT(DOW FROM full_date)::INT AS day_of_week,
    CASE WHEN EXTRACT(DOW FROM full_date) IN (0,6) THEN true ELSE false END AS is_weekend
FROM date_spine
ON CONFLICT (date_key) DO NOTHING;

-- DimCompany initial load
INSERT INTO DimCompany (company_key, company, company_clean, company_risk_tier, effective_from, effective_to, is_current, scd_version)
WITH distinct_companies AS (
    SELECT DISTINCT company FROM stg_complaints_raw WHERE company NOT ILIKE '%UNKNOWN%'
),
numbered AS (
    SELECT company, ROW_NUMBER() OVER (ORDER BY company) AS rn FROM distinct_companies
)
SELECT
    rn AS company_key,
    company,
    UPPER(TRIM(company)) AS company_clean,
    CASE 
        WHEN company ILIKE '%EQUIFAX%' OR company ILIKE '%Experian%' OR company ILIKE '%TRANSUNION%' THEN 'Critical'
        WHEN company ILIKE '%BANK OF AMERICA%' OR company ILIKE '%CHASE%' OR company ILIKE '%WELLS%' THEN 'High'
        ELSE 'Medium'
    END AS company_risk_tier,
    '2022-01-01'::date AS effective_from,
    '9999-12-31'::date AS effective_to,
    true AS is_current,
    1 AS scd_version
FROM numbered
ON CONFLICT DO NOTHING;

-- SCD2: Type 2 change example - BANK OF AMERICA reorg on 2023-07-01
-- Step 1: Expire old record
UPDATE DimCompany
SET effective_to = '2023-06-30',
    is_current = false
WHERE company = 'BANK OF AMERICA, NATIONAL ASSOCIATION'
  AND is_current = true;

-- Step 2: Insert new version
INSERT INTO DimCompany (company_key, company, company_clean, company_risk_tier, effective_from, effective_to, is_current, scd_version)
SELECT
    (SELECT MAX(company_key) FROM DimCompany) + 1,
    company,
    company_clean || ' (NEW ENTITY - 2023 MERGER)',
    company_risk_tier,
    '2023-07-01'::date,
    '9999-12-31'::date,
    true,
    scd_version + 1
FROM DimCompany
WHERE company = 'BANK OF AMERICA, NATIONAL ASSOCIATION'
  AND effective_to = '2023-06-30'
LIMIT 1;

-- Show SCD2 history
SELECT company_key, company, effective_from, effective_to, is_current, scd_version
FROM DimCompany
WHERE company LIKE '%BANK OF AMERICA%'
ORDER BY effective_from;

-- DimProduct
INSERT INTO DimProduct (product_key, product, sub_product, product_category, is_unexpected)
WITH distinct_products AS (
    SELECT DISTINCT product, sub_product FROM stg_complaints_raw
),
numbered AS (
    SELECT product, sub_product, ROW_NUMBER() OVER (ORDER BY product, sub_product) AS rn FROM distinct_products
)
SELECT
    rn,
    product,
    sub_product,
    CASE 
        WHEN product ILIKE '%Credit%' THEN 'Credit Services'
        WHEN product ILIKE '%loan%' OR product ILIKE '%Mortgage%' THEN 'Lending'
        ELSE 'Banking'
    END,
    product NOT IN (
        'Credit reporting, credit repair services, or other personal consumer reports',
        'Mortgage','Debt collection','Credit card',
        'Checking or savings account','Student loan',
        'Money transfer, virtual currency, or money service',
        'Payday loan, title loan, or personal loan')
FROM numbered;

-- DimGeography
INSERT INTO DimGeography (geography_key, state, zip_code, region, is_valid_state)
WITH distinct_geo AS (
    SELECT DISTINCT state, zip_code FROM stg_complaints_raw
),
numbered AS (
    SELECT state, zip_code, ROW_NUMBER() OVER (ORDER BY state, zip_code) AS rn FROM distinct_geo
)
SELECT
    rn,
    state,
    zip_code,
    CASE state
        WHEN 'CA' THEN 'West' WHEN 'WA' THEN 'West' WHEN 'OR' THEN 'West' WHEN 'NV' THEN 'West' WHEN 'AZ' THEN 'West' WHEN 'UT' THEN 'West' WHEN 'CO' THEN 'West' WHEN 'ID' THEN 'West' WHEN 'HI' THEN 'West' WHEN 'AK' THEN 'West' WHEN 'MT' THEN 'West' WHEN 'WY' THEN 'West' WHEN 'NM' THEN 'West'
        WHEN 'TX' THEN 'South' WHEN 'FL' THEN 'South' WHEN 'GA' THEN 'South' WHEN 'NC' THEN 'South' WHEN 'VA' THEN 'South' WHEN 'TN' THEN 'South' WHEN 'AL' THEN 'South' WHEN 'SC' THEN 'South' WHEN 'LA' THEN 'South' WHEN 'KY' THEN 'South' WHEN 'AR' THEN 'South' WHEN 'MS' THEN 'South' WHEN 'OK' THEN 'South' WHEN 'WV' THEN 'South' WHEN 'MD' THEN 'South' WHEN 'DE' THEN 'South' WHEN 'DC' THEN 'South'
        WHEN 'NY' THEN 'Northeast' WHEN 'PA' THEN 'Northeast' WHEN 'NJ' THEN 'Northeast' WHEN 'MA' THEN 'Northeast' WHEN 'CT' THEN 'Northeast' WHEN 'RI' THEN 'Northeast' WHEN 'NH' THEN 'Northeast' WHEN 'ME' THEN 'Northeast' WHEN 'VT' THEN 'Northeast'
        ELSE 'Midwest'
    END AS region,
    state IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')
FROM numbered;

-- Fact load with SCD2 join logic
INSERT INTO FactComplaints (
    complaint_id, date_key_received, date_key_sent, company_key, product_key,
    geography_key, issue_key, risk_key, days_to_company, timely_flag,
    has_narrative_flag, is_exception,
    dq_flag_missing_zip, dq_flag_unexpected_product, dq_flag_unmapped_company, dq_flag_late_arriving,
    complaint_hash
)
WITH cleaned AS (
    SELECT *
    FROM stg_complaints_raw
    WHERE date_received IS NOT NULL AND date_sent_to_company IS NOT NULL
      AND date_sent_to_company >= date_received
),
deduped AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY complaint_id ORDER BY date_received) AS rn
    FROM cleaned
)
SELECT
    c.complaint_id,
    TO_CHAR(c.date_received,'YYYYMMDD')::INT,
    TO_CHAR(c.date_sent_to_company,'YYYYMMDD')::INT,
    -- SCD2 join: match company where complaint date between effective_from and effective_to
    dc.company_key,
    dp.product_key,
    dg.geography_key,
    di.issue_key,
    dr.risk_key,
    (c.date_sent_to_company - c.date_received)::INT,
    CASE WHEN c.timely_response='Yes' THEN 1 ELSE 0 END,
    c.has_narrative,
    CASE WHEN c.timely_response='No' OR c.company ILIKE '%UNKNOWN%' THEN true ELSE false END,
    CASE WHEN c.zip_code IS NULL OR TRIM(c.zip_code)='' THEN true ELSE false END,
    CASE WHEN c.product NOT IN ('Credit reporting, credit repair services, or other personal consumer reports','Mortgage','Debt collection','Credit card','Checking or savings account','Student loan','Money transfer, virtual currency, or money service','Payday loan, title loan, or personal loan') THEN true ELSE false END,
    CASE WHEN c.company ILIKE '%UNKNOWN%' THEN true ELSE false END,
    CASE WHEN (c.date_sent_to_company - c.date_received) > 15 THEN true ELSE false END,
    MD5(c.complaint_id::TEXT)
FROM deduped c
LEFT JOIN DimCompany dc 
    ON dc.company = c.company 
    AND c.date_received::date BETWEEN dc.effective_from AND dc.effective_to
LEFT JOIN DimProduct dp ON dp.product = c.product AND COALESCE(dp.sub_product,'') = COALESCE(c.sub_product,'')
LEFT JOIN DimGeography dg ON dg.state = c.state AND COALESCE(dg.zip_code,'') = COALESCE(c.zip_code,'')
LEFT JOIN DimIssue di ON di.issue = c.issue AND COALESCE(di.sub_issue,'') = COALESCE(c.sub_issue,'')
LEFT JOIN DimRisk dr ON dr.risk_key = 
    CASE WHEN c.company ILIKE '%UNKNOWN%' THEN 3 WHEN c.timely_response='No' THEN 2 ELSE 4 END
WHERE c.rn = 1; -- duplicate treatment keep first
