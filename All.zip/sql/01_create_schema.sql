-- =============================================================
-- Consumer Complaint Intelligence - DDL Star Schema
-- Database: PostgreSQL / DuckDB compatible
-- Author: Data Analytics Portfolio
-- =============================================================

-- Drop if exists
DROP TABLE IF EXISTS FactComplaints;
DROP TABLE IF EXISTS DimDate;
DROP TABLE IF EXISTS DimCompany;
DROP TABLE IF EXISTS DimProduct;
DROP TABLE IF EXISTS DimGeography;
DROP TABLE IF EXISTS DimIssue;
DROP TABLE IF EXISTS DimRisk;
DROP TABLE IF EXISTS stg_complaints_raw;

-- Staging (Raw landing - exactly as CFPB source)
CREATE TABLE stg_complaints_raw (
    complaint_id BIGINT,
    date_received DATE,
    date_sent_to_company DATE,
    product VARCHAR(200),
    sub_product VARCHAR(200),
    issue VARCHAR(300),
    sub_issue VARCHAR(500),
    consumer_complaint_narrative TEXT,
    company VARCHAR(300),
    company_public_response VARCHAR(500),
    company_response_to_consumer VARCHAR(200),
    timely_response VARCHAR(10),
    consumer_consent_provided VARCHAR(50),
    submitted_via VARCHAR(50),
    state CHAR(2),
    zip_code VARCHAR(10),
    tags VARCHAR(200),
    has_narrative INT,
    _source_row_id BIGINT,
    load_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dimension Tables
CREATE TABLE DimDate (
    date_key INT PRIMARY KEY,
    full_date DATE NOT NULL,
    year INT NOT NULL,
    quarter INT NOT NULL,
    month INT NOT NULL,
    month_name VARCHAR(20),
    day INT NOT NULL,
    day_of_week INT NOT NULL,
    is_weekend BOOLEAN,
    is_holiday BOOLEAN DEFAULT FALSE
);

CREATE TABLE DimCompany (
    company_key INT PRIMARY KEY,
    company VARCHAR(300) NOT NULL,
    company_clean VARCHAR(350),
    company_risk_tier VARCHAR(20), -- Critical, High, Medium, Low
    effective_from DATE NOT NULL,
    effective_to DATE NOT NULL,
    is_current BOOLEAN NOT NULL,
    -- SCD2 audit
    scd_version INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE DimProduct (
    product_key INT PRIMARY KEY,
    product VARCHAR(200) NOT NULL,
    sub_product VARCHAR(200),
    product_category VARCHAR(50), -- Banking, Lending, Credit Services
    is_unexpected BOOLEAN DEFAULT FALSE
);

CREATE TABLE DimGeography (
    geography_key INT PRIMARY KEY,
    state CHAR(2),
    zip_code VARCHAR(10),
    region VARCHAR(20), -- West, South, Midwest, Northeast
    is_valid_state BOOLEAN,
    population INT -- optional enrichment
);

CREATE TABLE DimIssue (
    issue_key INT PRIMARY KEY,
    issue VARCHAR(300),
    sub_issue VARCHAR(500),
    severity_score INT DEFAULT 3
);

CREATE TABLE DimRisk (
    risk_key INT PRIMARY KEY,
    risk_category VARCHAR(100),
    risk_score INT,
    control_id VARCHAR(20),
    control_owner VARCHAR(100)
);

-- Fact Table
CREATE TABLE FactComplaints (
    complaint_id BIGINT PRIMARY KEY,
    date_key_received INT NOT NULL REFERENCES DimDate(date_key),
    date_key_sent INT NOT NULL REFERENCES DimDate(date_key),
    company_key INT NOT NULL REFERENCES DimCompany(company_key),
    product_key INT NOT NULL REFERENCES DimProduct(product_key),
    geography_key INT REFERENCES DimGeography(geography_key),
    issue_key INT REFERENCES DimIssue(issue_key),
    risk_key INT REFERENCES DimRisk(risk_key),
    
    -- Measures
    days_to_company INT,
    timely_flag INT CHECK (timely_flag IN (0,1)),
    has_narrative_flag INT CHECK (has_narrative_flag IN (0,1)),
    is_exception BOOLEAN,
    
    -- Data quality flags retained in fact for dashboarding
    dq_flag_missing_zip BOOLEAN,
    dq_flag_unexpected_product BOOLEAN,
    dq_flag_unmapped_company BOOLEAN,
    dq_flag_late_arriving BOOLEAN,
    
    complaint_hash VARCHAR(20),
    load_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_fact_date_received ON FactComplaints(date_key_received);
CREATE INDEX idx_fact_company ON FactComplaints(company_key);
CREATE INDEX idx_fact_product ON FactComplaints(product_key);
CREATE INDEX idx_fact_geo ON FactComplaints(geography_key);
CREATE INDEX idx_fact_exception ON FactComplaints(is_exception) WHERE is_exception = true;

-- Comments for lineage
COMMENT ON TABLE FactComplaints IS 'Grain: 1 row = 1 unique consumer complaint after deduplication. Source: CFPB CCDB.';
COMMENT ON COLUMN FactComplaints.is_exception IS 'TRUE if timely breach OR unmapped company OR unexpected product';
