-- =============================================================
-- 02 - Staging, Data Quality, and Reconciliation
-- Demonstrates: CTEs, conditional aggregation, duplicate detection
-- =============================================================

-- -------------------------------------------------------------
-- SOURCE-TO-REPORT RECONCILIATION CTE
-- Equation: Source rows - rejected rows - duplicate treatment = reporting rows
-- -------------------------------------------------------------
WITH source_counts AS (
    SELECT COUNT(*) AS source_rows FROM stg_complaints_raw
),
invalid_dates AS (
    SELECT COUNT(*) AS rejected_invalid_dates
    FROM stg_complaints_raw
    WHERE date_received IS NULL
       OR date_sent_to_company IS NULL
       OR date_sent_to_company < date_received
       OR date_sent_to_company > CURRENT_DATE + INTERVAL '30 days'
),
duplicates AS (
    SELECT complaint_id, COUNT(*) - 1 AS dup_extra
    FROM stg_complaints_raw
    WHERE date_received IS NOT NULL AND date_sent_to_company >= date_received
    GROUP BY complaint_id
    HAVING COUNT(*) > 1
),
dedup_summary AS (
    SELECT COALESCE(SUM(dup_extra),0) AS duplicate_removed FROM duplicates
),
fact_counts AS (
    SELECT COUNT(*) AS reporting_rows FROM FactComplaints
)
SELECT
    s.source_rows,
    i.rejected_invalid_dates,
    d.duplicate_removed,
    f.reporting_rows,
    (s.source_rows - i.rejected_invalid_dates - d.duplicate_removed) AS expected_reporting,
    (s.source_rows - i.rejected_invalid_dates - d.duplicate_removed - f.reporting_rows) AS diff,
    CASE WHEN (s.source_rows - i.rejected_invalid_dates - d.duplicate_removed) = f.reporting_rows
         THEN 'PASS' ELSE 'FAIL' END AS reconciliation_status
FROM source_counts s, invalid_dates i, dedup_summary d, fact_counts f;

-- -------------------------------------------------------------
-- DATA QUALITY DASHBOARD - Single query output for dashboard
-- Demonstrates: conditional aggregation
-- -------------------------------------------------------------
WITH quality_flags AS (
    SELECT
        COUNT(*) AS total_source,
        -- missing values
        SUM(CASE WHEN zip_code IS NULL OR TRIM(zip_code) = '' THEN 1 ELSE 0 END) AS missing_zip,
        SUM(CASE WHEN consumer_complaint_narrative IS NULL THEN 1 ELSE 0 END) AS missing_narrative,
        -- duplicates
        COUNT(*) - COUNT(DISTINCT complaint_id) AS duplicate_complaint_ids,
        -- invalid dates
        SUM(CASE WHEN date_sent_to_company < date_received THEN 1 ELSE 0 END) AS invalid_date_logic,
        SUM(CASE WHEN date_received IS NULL OR date_sent_to_company IS NULL THEN 1 ELSE 0 END) AS null_dates,
        SUM(CASE WHEN date_sent_to_company > CURRENT_DATE THEN 1 ELSE 0 END) AS future_dates,
        -- unexpected categories
        SUM(CASE WHEN product NOT IN (
            'Credit reporting, credit repair services, or other personal consumer reports',
            'Mortgage','Debt collection','Credit card',
            'Checking or savings account','Student loan',
            'Money transfer, virtual currency, or money service',
            'Payday loan, title loan, or personal loan') THEN 1 ELSE 0 END) AS unexpected_products,
        SUM(CASE WHEN state NOT IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') THEN 1 ELSE 0 END) AS invalid_states,
        -- unmapped entities
        SUM(CASE WHEN company ILIKE '%UNKNOWN ENTITY%' THEN 1 ELSE 0 END) AS unmapped_companies,
        -- timely breach
        SUM(CASE WHEN timely_response = 'No' THEN 1 ELSE 0 END) AS timely_breach,
        -- late arriving: sent >15 days after received
        SUM(CASE WHEN (date_sent_to_company - date_received) > 15 THEN 1 ELSE 0 END) AS late_arriving
    FROM stg_complaints_raw
)
SELECT
    total_source,
    ROUND(missing_zip*100.0/total_source,2) AS pct_missing_zip,
    ROUND((invalid_date_logic+null_dates+future_dates)*100.0/total_source,2) AS pct_invalid_dates,
    ROUND(unexpected_products*100.0/total_source,2) AS pct_unexpected_products,
    ROUND(invalid_states*100.0/total_source,2) AS pct_invalid_states,
    ROUND(unmapped_companies*100.0/total_source,2) AS pct_unmapped,
    duplicate_complaint_ids,
    timely_breach,
    late_arriving,
    (missing_zip + duplicate_complaint_ids + invalid_date_logic + unexpected_products + unmapped_companies) AS total_exceptions_for_review
FROM quality_flags;

-- -------------------------------------------------------------
-- DUPLICATE DETECTION - Show detail
-- Demonstrates: window functions for duplicate detection
-- -------------------------------------------------------------
WITH ranked_complaints AS (
    SELECT
        complaint_id,
        date_received,
        date_sent_to_company,
        company,
        product,
        ROW_NUMBER() OVER (PARTITION BY complaint_id ORDER BY date_received ASC) AS rn,
        COUNT(*) OVER (PARTITION BY complaint_id) AS cnt_per_id
    FROM stg_complaints_raw
)
SELECT *
FROM ranked_complaints
WHERE cnt_per_id > 1
ORDER BY complaint_id, rn;

-- -------------------------------------------------------------
-- UNMAPPED ENTITIES DRILL
-- -------------------------------------------------------------
SELECT company, COUNT(*) AS complaints, 'Unmapped - No Master Record' AS reason
FROM stg_complaints_raw
WHERE company ILIKE '%UNKNOWN%'
GROUP BY company
ORDER BY complaints DESC;

-- -------------------------------------------------------------
-- LATE ARRIVING DATA MONITOR
-- -------------------------------------------------------------
SELECT
    DATE_TRUNC('month', date_received) AS complaint_month,
    COUNT(*) AS total,
    SUM(CASE WHEN (date_sent_to_company - date_received) > 15 THEN 1 ELSE 0 END) AS late_gt15,
    ROUND(SUM(CASE WHEN (date_sent_to_company - date_received) > 15 THEN 1 ELSE 0 END)*100.0/COUNT(*),2) AS late_pct
FROM stg_complaints_raw
WHERE date_received IS NOT NULL
GROUP BY 1
ORDER BY 1 DESC;
