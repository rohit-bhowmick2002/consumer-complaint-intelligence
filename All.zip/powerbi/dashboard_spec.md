# Power BI Dashboard Specification - Consumer Complaint Intelligence

## Overview
- **Type:** Power BI Pro - App Workspace: Consumer Risk & Controls
- **Dataset:** 17,345 rows FactComplaints + 6 dims, ~ 618 KB model (sample), 5M+ in prod
- **Refresh:** Daily 6 AM EST after CFPB nightly update + reconciliation check - if FAIL, dataset refresh blocked + alert to Data Eng
- **RLS:** Compliance Ops sees all, Product Risk Manager sees only their product_category

## Pages (7 pages + 1 drill-through)

### Page 1: Executive Summary (One-page mandated)
- **Visuals:**
  - Cards: Total Complaints (17,345), Exceptions (7,725), Exception Rate (44.5%), Timely Breach Rate (43.1%), Est Exposure $3.39M, Reconciliation Status PASS
  - Line: Rolling 12M Complaints vs Exceptions (trend last 24 months)
  - Bar: Exception Rate by Company Risk Tier (Critical 45.9%, High 44.8%, Medium 44.2%)
  - Donut: Product Contribution %
  - Table: Top 5 Companies by Exception Rate with peer percentile (drill-through enabled)
  - What-If Slicers: SLA Threshold (1-30, default 15), Cost per Complaint ($100-$5000, default $450)
  - Gauge: DQ Score 88% vs Target 95%
- **Filters:** Year 2022-2025, Region
- **Alert:** If Exception Rate >30% => red background via conditional formatting + alert to CCO

### Page 2: Source-to-Report Reconciliation
- **Visuals:**
  - Waterfall: Source 18000 -> Rejected 504 -> Duplicate 151 -> Reporting 17345
  - Card: Diff 0, Status PASS (green check)
  - Table: audit_reconciliation history last 10 runs
  - Matrix: Rejection reason breakdown
- **Logic:** Measure `Reconciliation Difference` must be 0 else card red + stop

### Page 3: Data Quality Dashboard
- **Visuals (7 mandatory tiles):**
  - Missing zip tile: 371 (2.06%) - Donut
  - Duplicate tile: 151 extra - Card
  - Invalid dates: 504 rejected - Bar by month
  - Unexpected categories: 180 (Crypto etc) - Table
  - Unmapped entities: 246 - Table with company
  - Reconciliation differences: PASS/Fail card
  - Late-arriving: 13.9% -> 43.1% actual timeliness breach confusion -> Line chart month trend showing 42-45%
- **Drill:** Click unmapped entity -> goes to Complaint Detail page filtered to that company

### Page 4: Company Risk & Peer Percentile
- **Visuals:**
  - Scatter: X=Total Complaints, Y=Exception Rate, size=Est Exposure, color=Risk Tier
  - Table: Company, Total, Exceptions, Exception Rate, Peer Percentile, Rank, Concentration, Owner
  - Bar: Top 10 companies by exception rate
  - Slicer: Risk Tier
- **DAX used:** Company Peer Percentile Rank, RANKX, Contribution %
- **Drill-through:** Right-click company -> Drillthrough to Complaint Detail + Actionable

### Page 5: Product & Issue Deep Dive
- **Visuals:**
  - Matrix: Product x Issue with exception rate conditional formatting
  - Treemap: Contribution % by product_category
  - Line: YoY change per product
  - Bar: Issue exception rate
- **Insight:** Credit reporting product drives 58% of credit category, incorrect info issue 12.4% exception rate

### Page 6: Geographic Hotspots & Ageing
- **Visuals:**
  - Map: US state complaint per 1k population (requires external pop, simulated)
  - Line: State z-score anomaly detection (flag >2)
  - Column: Ageing Buckets 0-1,2-5,6-15,16-30,30+ with exception rate overlay
  - Table: State, count, avg days, anomaly flag
- **DAX:** Ageing Bucket calculated column, Z-Score measure, Is Anomaly

### Page 7: Actionable Output (Operational)
- **Visuals:**
  - Table: actionable_exceptions.csv live query - columns: complaint_id, company, product, exception_type, owner, due_date, status, priority, recommended_action, drillthrough_path
  - KPI: Open exceptions 5163, In Progress 2562, P1 218
  - Bar: Count by owner
  - Card: Total Exposure $3.39M
  - Filter: Priority P1 only button
- **Action:** Export -> paginated report to ServiceNow

### Page 8: Drill-Through - Complaint Detail (hidden)
- **Filters:** Comes from any page when complaint_id selected
- **Visuals:**
  - Card: Complaint ID, hash
  - Details: Date received, sent, company, product, sub-product, issue, sub-issue, state, zip, submitted via, company response
  - Narrative: consumer_complaint_narrative (if has_narrative_flag)
  - Timeline: Received -> Sent (days)
  - Flags: DQ flags checkboxes
  - Risk: Risk category, control_id, owner
  - Recommended action & due date
  - Buttons: Link to ServiceNow, Back to Executive

## DAX Measures Used (from dax/measures.dax)

- Total Complaints, Total Exceptions, Exception Rate
- Rolling 12M, Rolling 3M Avg
- YoY Change, YoY Absolute, PY
- Company Contribution %, Product Contribution %, Cumulative
- Peer Percentile Rank, Peer Rank
- Ageing Bucket, Critical Ageing %
- Concentration Top 3, Herfindahl Index
- What-If: Breaching SLA, Exposure $
- Anomaly: Z-Score, Is Anomaly
- DQ: Missing Zip Count, Unmapped, Late Arriving Rate, DQ Score, Reconciliation Difference

## Data Model Relationships (Power BI)

- DimDate (date_key) 1:* FactComplaints.date_key_received (active)
- DimDate (date_key) 1:* FactComplaints.date_key_sent (inactive, use USERELATIONSHIP)
- DimCompany 1:* FactComplaints
- DimProduct 1:* FactComplaints
- DimGeography 1:* FactComplaints
- DimIssue 1:* FactComplaints
- DimRisk 1:* FactComplaints

## What-If Parameters

1. **SLA Threshold**: GENERATESERIES(1,30,1) default 15
2. **Cost per Complaint**: GENERATESERIES(100,5000,50) default 450

## Performance Recommendations

- Aggregations: agg table monthly for rolling 12M (not needed for 17k but for 5M+ prod)
- Incremental refresh: filter DimDate last 3 years + 1 year future, Fact by date_received
- Query reduction on slicers

## Deployment Checklist

- [ ] Dataflow for CFPB complaints.csv.zip ingestion (Python notebook in ADF)
- [ ] Reconciliation check gate: if FAIL, don't publish
- [ ] RLS roles tested
- [ ] Drill-through from every KPI tested to complaint detail
- [ ] What-If parameters working for exposure
- [ ] Alerts configured for exception rate > threshold + unmapped>0
- [ ] Paginated report export for actionable_exceptions
- [ ] App workspace shared to CCO, Compliance Ops, Risk
